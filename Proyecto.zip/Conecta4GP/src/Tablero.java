
public class Tablero {
	private String[][] tablero;
	private String ganador;
	public Tablero(int x, int y) { //creamos el tablero
		ganador="-";
		tablero= new String[y][x];
		for (int i=0;i<y;i++) { //recorremos la y
			for (int k=0;k<x;k++) { //recorremos la x
				tablero[i][k]="-"; //por defecto vacio
			}
		}
	}
	
	public void imprimirTablero() {
		//Imprime el tablero en la terminal
		int ty=tablero.length;
		int tx=tablero[0].length;
		for (int i=0;i<ty;i++) {
			System.out.print("\n");
			for (int k=0;k<tx;k++) {
				System.out.print(tablero[i][k]);
			}
		}
				
	}
	public String getPosicion(int x, int y) { 
		//Post: Devuelve lo que hay en la posicion indicada (- si vacio, Rojo si J1, Azul si J2)
		int ty=tablero.length;
		int tx=tablero[0].length;
		
		if (x>tx ||x<0) { //posicion incorrecta (hay que tratarla)
			return null;
		}
		else if (y>ty || y<0) { //posicion incorrecta (hay que tratarla)
			return null;
		}
		else {
			return tablero[y][x];
		}
	}
	public void colocarFicha(int x, String color) {
		//busca la posicion mas baja y coloca ahi la ficha
		int tx=tablero[0].length;
		if (x<tx && sePuedeColocar(x)) {
			int ty=tablero.length;
			for (int i=ty-1;i>=0;i--) { //recorremos de forma inversa
				if (tablero[i][x].equals("-")) {
					tablero[i][x]=color;
					break;
				}
			}
		}
	}
	public boolean sePuedeColocar(int x) { 
		//Post: Devuelve true si se puede colocar
		int ty=tablero.length;
		for (int i=ty-1;i>=0;i--) { //recorremos de forma inversa
			if (tablero[i][x].equals("-")) {
				return true;
			}
		}
		return false;
	}
	public boolean hayGanador() {
		if (buscarGanadorEnVertical()||buscarGanadorEnHorizontal()||buscarGanadorEnDiagonal()) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean buscarGanadorEnVertical() {
		//Devuelve true si hay un ganador en vertical y almacena el color en ganador
		int ty=tablero.length;
		int tx=tablero[0].length;
		int countRojo=0;
		int countAzul=0;
		for (int x=0;x<tx;x++) { //Recorres la x
			for (int y=0;y<ty;y++) { //Recorres la y
				if (countRojo==4||countAzul==4) {
					return true;
				}
				if (tablero[y][x].equals("R")){ //ficha roja, se incrementa contador rojo y azul=0
					countRojo++;
					countAzul=0;
				}
				else if (tablero[y][x].equals("A")) { //ficha azul, se incrementa contador azul y rojo=0
					countAzul++;
					countRojo=0;
				}
				else { //Esta vacia, se reinician los contadores
					countRojo=0;
					countAzul=0;
				}
			} //fin for ys
		} //fin for x
		return false;
	}
	public boolean buscarGanadorEnHorizontal(){
		//Devuelve true si hay un ganador en horizontal y almacena el color en ganador
		int ty=tablero.length;
		int tx=tablero[0].length;
		int countRojo=0;
		int countAzul=0;
		for (int y=0;y<ty;y++) { //Recorres la y
			for (int x=0;x<tx;x++) { //Recorres la x
				if (countRojo==4||countAzul==4) {
					if (countRojo==4) {
						ganador="R";
					}
					else {
						ganador="A";
					}
					return true;
				}
				if (tablero[y][x].equals("R")){ //ficha roja, se incrementa contador rojo y azul=0
					countRojo++;
					countAzul=0;
				}
				else if (tablero[y][x].equals("A")) { //ficha azul, se incrementa contador azul y rojo=0
					countAzul++;
					countRojo=0;
				}
				else { //Esta vacia, se reinician los contadores
					countRojo=0;
					countAzul=0;
				}
			} //fin for x
		} //fin for y
		return false;
	}
	public boolean buscarGanadorEnDiagonal() {
		//Devuelve true si hay ganador en diagonal y almacena el color en ganador
		return false;
	}
	public String getGanador() {
		//Devuelve el atributo ganador (recomendable comprobar primero si hay ganador
		return ganador;
	}
}
