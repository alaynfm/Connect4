import java.util.Stack;

public class Tablero {

	private String[][] tablero;
	private String ganador;

	public Tablero(int x, int y) { // creamos el tablero
		ganador = "-";
		tablero = new String[y][x];
		for (int i = 0; i < y; i++) { // recorremos la y
			for (int k = 0; k < x; k++) { // recorremos la x
				tablero[i][k] = "-"; // por defecto vacio
			}
		}
	}

	public void imprimirTablero() {
		// Imprime el tablero en la terminal
		int ty = tablero.length;
		int tx = tablero[0].length;
		for (int i = 0; i < ty; i++) {
			System.out.print("\n");
			for (int k = 0; k < tx; k++) {
				System.out.print(tablero[i][k]);
			}
		}

	}

	public String getPosicion(int x, int y) {
		// Post: Devuelve lo que hay en la posicion indicada (- si vacio, Rojo si J1,
		// Azul si J2)
		int ty = tablero.length;
		int tx = tablero[0].length;

		if (x > tx || x < 0) { // posicion incorrecta (hay que tratarla)
			return null;
		} else if (y > ty || y < 0) { // posicion incorrecta (hay que tratarla)
			return null;
		} else {
			return tablero[y][x];
		}
	}

	public void colocarFicha(int x, String color) {
		// busca la posicion mas baja y coloca ahi la ficha
		int tx = tablero[0].length;
		if (x < tx && sePuedeColocar(x)) {
			int ty = tablero.length;
			for (int i = ty - 1; i >= 0; i--) { // recorremos de forma inversa
				if (tablero[i][x].equals("-")) {
					tablero[i][x] = color;
					buscarGanador(i, x);
					break;
				}
			}
		}
	}

	public boolean sePuedeColocar(int x) {
		// Post: Devuelve true si se puede colocar
		int ty = tablero.length;
		for (int i = ty - 1; i >= 0; i--) { // recorremos de forma inversa
			if (tablero[i][x].equals("-")) {
				return true;
			}
		}
		return false;
	}

	public void buscarGanador(int i, int x) {
		if (buscarGanadorEnVertical(i, x) || buscarGanadorEnHorizontal(i, x) || buscarGanadorEnDiagonal(i, x)) {
			ganador = tablero[i][x];
		}
	}

	public boolean hayGanador() {
		if (ganador.equals("-"))
			return false;
		else
			return true;
	}

	public boolean buscarGanadorEnVertical(int fila, int columna) {
		// Devuelve true si hay un ganador en vertical y almacena el color en ganador

		String color = tablero[fila][columna];
		int contArriba = 1;
		int contAbajo = 1;

		// hacia arriba
		for (int i = 1; i <= 4; i++) {

			if (contArriba == 4 || contAbajo == 4) {
				break;
			} else {

				// Arriba
				if (posCorrecta(fila + i, columna)) {
					if ((tablero[fila + i][columna]).equals(color)) {
						contArriba++;
					}
				} 
				
				if (posCorrecta(fila - i, columna)) {
					if ((tablero[fila - 1][columna]).equals(color)) {
						contAbajo++;
					}
				}
			}
		}

		if (contAbajo == 4 || contArriba == 4)
			return true;
		else
			return false;

	}

	public boolean buscarGanadorEnHorizontal(int fila, int columna) {

		String color = tablero[fila][columna];
		int contArriba = 1;
		int contAbajo = 1;

		// hacia arriba
		for (int i = 1; i < 4; i++) {

			if (contArriba == 4 || contAbajo == 4) {
				break;
			} else {

				// Derecha
				if (posCorrecta(fila, columna + i)) {
					if ((tablero[fila][columna + i]).equals(color)) {
						contArriba++;
					}
					// Izquierda
				} 
				if (posCorrecta(fila, columna - i)) {
					if ((tablero[fila][columna - i]).equals(color)) {
						contAbajo++;
					}
				}
			}
		}

		if (contAbajo == 4 || contArriba == 4)
			return true;
		else
			return false;

	}

	public boolean buscarGanadorEnDiagonal(int fila, int columna) {
		String color = tablero[fila][columna];
		int contArriba = 1;
		int contAbajo = 1;


		// hacia arriba
		for (int i = 1; i < 4; i++) {

			if (contArriba == 4 || contAbajo == 4) {
				break;
			} else {

				//hacia abajo izquierda
				if (posCorrecta(fila + i, columna - i)) {
					if ((tablero[fila + i][columna - i]).equals(color)) {
						contArriba++;
					}
				}
				
				//hacia arriba derecha
				if (posCorrecta(fila - i, columna + i)) {
					if ((tablero[fila - i][columna + i]).equals(color)) {
						contAbajo++;
					}
				}
				
				//hacia abajo derecha
				if (posCorrecta(fila + i, columna + i)) {
					if ((tablero[fila + i][columna + i]).equals(color)) {
						contAbajo++;
					}
				}
				
				//hacia arriba izq
				if (posCorrecta(fila - i, columna - i)) {
					if ((tablero[fila - i][columna - i]).equals(color)) {
						contAbajo++;
					}
				}
			}

		}

		if (contAbajo == 4 || contArriba == 4)
			return true;
		else
			return false;

	}

	private Boolean posCorrecta(int i, int j) {
		if (i < tablero.length && j < tablero[0].length && i >= 0 & j >= 0)
			return true;
		else
			return false;

	}

	public String getGanador() {
		// Devuelve el atributo ganador (recomendable comprobar primero si hay ganador
		return ganador;
	}

}
