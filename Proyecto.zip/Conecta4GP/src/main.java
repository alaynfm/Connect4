
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tablero x= new Tablero(9,6);
		//x.imprimirTablero();
		
		x.colocarFicha(0, "R");
		x.colocarFicha(0, "R");
		x.colocarFicha(0, "R");
		x.colocarFicha(0, "R");
		x.colocarFicha(0, "R");
		x.colocarFicha(1, "A");
		x.colocarFicha(2, "A");
		x.colocarFicha(3, "A");
		x.colocarFicha(4, "A");
		x.colocarFicha(8,"A");
		System.out.println("Hay victoria: "+x.hayGanador());
		//x.colocarFicha(0, "A");
		System.out.println(x.sePuedeColocar(0));
		x.imprimirTablero();
	}

}
